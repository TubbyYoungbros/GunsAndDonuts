﻿using UnityEngine;
using System.Collections;

public class StartWaveStory : MonoBehaviour {

    public WaveSpawner GM;
    public float standCountDown;
    public GameObject fullObject;

    [SerializeField]
    private GameObject player;

    // Use this for initialization
    void Start()
    {

    }

    void OnTriggerEnter2D(Collider2D obj)
    {

        GM = GameObject.Find("WaveManager(Clone)").GetComponent<WaveSpawner>();
        /*if (obj.gameObject.tag == "Player")
        {
            fullObject.SetActive(false);
            ammoShop.SetActive(false);
            damageShop.SetActive(false);
            healthShop.SetActive(false);
            speedShot.SetActive(false);
            GM.waveCountdown = 5f;
        }if(GM.waveCountdown <= 0f)
        {
        }*/
    }

    void OnTriggerStay2D(Collider2D obj)
    {
        Debug.Log("standing here");
        if (obj.gameObject.tag == "Player")
        {
            if (standCountDown <= 0)
            {
                StartWaveFunction();
                standCountDown = 1;
            }
            else
            {
                standCountDown -= Time.deltaTime;
            }
        }
    }
    void OnTriggerExit2D(Collider2D obj)
    {
        if (obj.gameObject.tag == "Player")
        {
            standCountDown = 1;
        }
    }

    void StartWaveFunction()
    {
        GM = GameObject.Find("WaveManager(Clone)").GetComponent<WaveSpawner>();
        fullObject.SetActive(false);
        GM.canCount = true;
        GM.waveCountdown = 5f;
        GM.enemyLeft = 0;
    }
}
