﻿using UnityEngine;
using System.Collections;

public class EnemyGrape : MonoBehaviour {

    public string type;
    public GameObject body;
    public GameObject player;
    public float speed;
    public float maxSpeed;
    public int lookDir;
    Rigidbody2D myRB;

    public GameObject[] crumbs;
    public GameObject crumbSpawn;
    public GameObject crumbToDrop;
    public int timesToDrop;
    public GameObject junk;

    public Animator bodyAnim;

    // Use this for initialization
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        lookDir = 1;
        myRB = GetComponent<Rigidbody2D>();
        junk = GameObject.Find("Junk Folder");

        if (type == "Mini")
        {
            for (int i = 0; i <= timesToDrop; i++)
            {
                int crumbNumber = Random.Range(0, crumbs.Length);
                float randomDropZoneX = Random.Range(-.405f, .605f);
                float randomDropZoneY = Random.Range(-.605f, .305f);
                crumbToDrop = crumbs[crumbNumber];

                GameObject crumb1 = (GameObject)Instantiate(crumbToDrop, crumbSpawn.transform.position + new Vector3(randomDropZoneX, randomDropZoneY, 0), Quaternion.identity);
                crumb1.transform.SetParent(junk.transform);
            }
        }
    }

    void Update()
    {
        LookTo();
    }
    void FixedUpdate()
    {
        Runto();
    }

    void LookTo()
    {
        Vector3 playPos = player.transform.position;
        if (playPos.x <= transform.position.x)
        {
            lookDir = -1;
        }
        else if (playPos.x >= transform.position.x)
        {
            lookDir = 1;
        }
        body.transform.localScale = new Vector3(lookDir, transform.localScale.y, transform.localScale.z);
    }

    void Runto()
    {
        Vector3 dir = player.transform.position - transform.position;

        dir.Normalize();

        transform.position = transform.position + dir * speed * Time.deltaTime;

    }
}
