﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GrenadeShop : MonoBehaviour {

    public int baseCost;
    public int newCost;
    public string type;
    public Text price;
    public GameObject tipCanvas;

    public AudioClip suceed;
    public AudioClip error;

    public PlayerMoneyManager playerManager;
    // Use this for initialization
    void Start()
    {
        tipCanvas.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
            price.text = baseCost + "\n" + "Coins";
    }

    void OnTriggerEnter2D(Collider2D obj)
    {
        if (obj.gameObject.tag == "Player")
        {
            PlayerMoneyManager player = obj.gameObject.GetComponent<PlayerMoneyManager>();
            player.enabled = true;
            player.shopType = type;
            tipCanvas.SetActive(true);
        }
    }
    void OnTriggerExit2D(Collider2D obj)
    {
        if (obj.gameObject.tag == "Player")
        {
            PlayerMoneyManager player = obj.gameObject.GetComponent<PlayerMoneyManager>();
            player.enabled = false;
            player.shopType = null;
            tipCanvas.SetActive(false);
        }
    }
}
