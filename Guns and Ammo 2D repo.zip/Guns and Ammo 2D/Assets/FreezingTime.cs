﻿using UnityEngine;
using System.Collections;

public class FreezingTime : MonoBehaviour {

    AIPath moveScript;

    public bool slowdown = false;
    bool speedup = false;

	// Use this for initialization
	void Start () {
        moveScript = this.gameObject.GetComponent<AIPath>();
	}
	
	// Update is called once per frame
	void Update () {
        if (slowdown == true)
        {
            moveScript.speed -= Time.deltaTime;
            if(moveScript.speed <= 0)
            {
                slowdown = false;
                moveScript.speed = 0;
            }
            if(moveScript.speed == 0)
            {
                StartCoroutine(FreezeTime());
                moveScript.bodyAnim.enabled = false;
            }
            if (speedup == true)
            {
                moveScript.speed += 0.1f;
                Debug.Log(moveScript.speed);
                Debug.Log("here");
                if (moveScript.speed >= moveScript.maxSpeed)
                {
                    speedup = false;
                    moveScript.speed = moveScript.maxSpeed;
                }
            }
        }
	}

    IEnumerator FreezeTime()
    {
        yield return new WaitForSeconds(3);
        moveScript.speed = moveScript.maxSpeed;
        moveScript.bodyAnim.enabled = true;
    }
}
