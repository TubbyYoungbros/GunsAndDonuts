﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;

public class CharacterGrenadeInventory : MonoBehaviour {

    public List<string> grenadeList = new List<string>();

    int arrayPos = 0;

    public int frozenGrenades;
    public int regularGrenades;
    public int fireGrenades;
    public int leadingGrenades;

    public GameObject frozenPic, regularPic, firePic, leadingPic, selectionArrow, throwText;
    public GameObject frozen, regular, fire, leading, spawnPoint;

    public int grenadeSpeed;

    public GameObject currentGrenade;
    public string currentGrenadeName;

    AudioSource myAudio;
    public AudioClip throwNade;

    // Use this for initialization
    void Start () {
        frozenGrenades = 0;
        regularGrenades = 0;
        fireGrenades = 0;
        leadingGrenades = 0;

        myAudio = GameObject.FindGameObjectWithTag("Audio").GetComponent<AudioSource>();

        frozenPic = GameObject.Find("FrozenGrenade");
        regularPic = GameObject.Find("RegularGrenade");
        firePic = GameObject.Find("FireGrenade");
        leadingPic = GameObject.Find("LeadingGrenade");
        selectionArrow = GameObject.Find("SelectionArrow");
        throwText = GameObject.Find("ThrowText");

        selectionArrow.SetActive(false);
        throwText.SetActive(false);
    }
	
	// Update is called once per frame
	void Update () {
        FindGrenades();
        HandleInputs();
    }

    void HandleInputs()
    {
        if (grenadeList.Count == 1)
        {
            currentGrenadeName = grenadeList[0];
            selectionArrow.SetActive(true);
            throwText.SetActive(true);
        }

        if (Input.GetKeyUp(KeyCode.Tab))
        {
            if(arrayPos >= grenadeList.Count - 1)
            {
                arrayPos = 0;
            }else
            {
                arrayPos += 1;
            }
            currentGrenadeName = grenadeList[arrayPos];
        }
        
        if(grenadeList.Count < 1)
        {
            arrayPos = 0;
        }

        if(grenadeList.Count > 0)
        {
            if (Input.GetKeyUp(KeyCode.G))
            {
                if(currentGrenadeName == "Regular")
                {
                    grenadeList.Remove("Regular");
                    regularGrenades = 0;
                    currentGrenadeName = null;
                    ThrowRegularGrenades();
                    if(grenadeList.Count > 0)
                    {
                        currentGrenadeName = grenadeList[arrayPos - 1];
                    }else
                    {
                        selectionArrow.SetActive(false);
                        throwText.SetActive(false);
                    }
                }else if (currentGrenadeName == "Frozen")
                {
                    grenadeList.Remove("Frozen");
                    frozenGrenades = 0;
                    currentGrenadeName = null;
                    ThrowFrozenGrenades();
                    if (grenadeList.Count > 0)
                    {
                        currentGrenadeName = grenadeList[arrayPos - 1];
                    }
                    else
                    {
                        selectionArrow.SetActive(false);
                        throwText.SetActive(false);
                    }
                }
                else if (currentGrenadeName == "Leading")
                {
                    grenadeList.Remove("Leading");
                    leadingGrenades = 0;
                    currentGrenadeName = null;
                    ThrowLeadingGrenades();
                    if (grenadeList.Count > 0)
                    {
                        currentGrenadeName = grenadeList[arrayPos - 1];
                    }
                    else
                    {
                        selectionArrow.SetActive(false);
                        throwText.SetActive(false);
                    }
                }
                else if (currentGrenadeName == "Fire")
                {
                    grenadeList.Remove("Fire");
                    fireGrenades = 0;
                    currentGrenadeName = null;
                    ThrowFire();
                    if (grenadeList.Count > 0)
                    {
                        currentGrenadeName = grenadeList[arrayPos - 1];
                    }
                    else
                    {
                        selectionArrow.SetActive(false);
                        throwText.SetActive(false);
                    }
                }
            }
        }
    }

    void ThrowRegularGrenades()
    {
        GameObject nade = Instantiate(regular, spawnPoint.transform.position, transform.rotation) as GameObject;
        Rigidbody2D nadeRB = nade.GetComponent<Rigidbody2D>();

        Vector3 dir = Input.mousePosition - Camera.main.WorldToScreenPoint(transform.position);
        dir.Normalize();
        nadeRB.AddForce(dir * grenadeSpeed);

        myAudio.PlayOneShot(throwNade);
    }

    void ThrowFire()
    {
        GameObject nade = Instantiate(fire, spawnPoint.transform.position, transform.rotation) as GameObject;
        Rigidbody2D nadeRB = nade.GetComponent<Rigidbody2D>();

        Vector3 dir = Input.mousePosition - Camera.main.WorldToScreenPoint(transform.position);
        dir.Normalize();
        nadeRB.AddForce(dir * grenadeSpeed);

        myAudio.PlayOneShot(throwNade);
        //toss sound
    }

    void ThrowFrozenGrenades()
    {
        GameObject nade = Instantiate(frozen, spawnPoint.transform.position, transform.rotation) as GameObject;
        Rigidbody2D nadeRB = nade.GetComponent<Rigidbody2D>();

        Vector3 dir = Input.mousePosition - Camera.main.WorldToScreenPoint(transform.position);
        dir.Normalize();
        nadeRB.AddForce(dir * grenadeSpeed);
        myAudio.PlayOneShot(throwNade);
    }
    void ThrowLeadingGrenades()
    {
        GameObject nade = Instantiate(leading, spawnPoint.transform.position, transform.rotation) as GameObject;
        Rigidbody2D nadeRB = nade.GetComponent<Rigidbody2D>();

        Vector3 dir = Input.mousePosition - Camera.main.WorldToScreenPoint(transform.position);
        dir.Normalize();
        nadeRB.AddForce(dir * grenadeSpeed);
        myAudio.PlayOneShot(throwNade);
    }

    void FindGrenades()
    {
        if(frozenGrenades >= 1)
        {
            frozenPic.gameObject.SetActive(true);
        }else if(frozenGrenades < 1)
        {
            frozenPic.gameObject.SetActive(false);
        }

        if (regularGrenades >= 1)
        {
            regularPic.gameObject.SetActive(true);
        }
        else if (regularGrenades < 1)
        {
            regularPic.gameObject.SetActive(false);
        }

        if (fireGrenades >= 1)
        {
            firePic.gameObject.SetActive(true);
        }
        else if (fireGrenades < 1)
        {
            firePic.gameObject.SetActive(false);
        }

        if (leadingGrenades >= 1)
        {
            leadingPic.gameObject.SetActive(true);
        }
        else if (frozenGrenades < 1)
        {
            leadingPic.gameObject.SetActive(false);
        }


        if(currentGrenadeName == "Regular")
        {
            selectionArrow.transform.position = new Vector2(regularPic.transform.position.x, selectionArrow.transform.position.y);
        }
        if (currentGrenadeName == "Frozen")
        {
            selectionArrow.transform.position = new Vector2(frozenPic.transform.position.x, selectionArrow.transform.position.y);
        }
        if (currentGrenadeName == "Leading")
        {
            selectionArrow.transform.position = new Vector2(leadingPic.transform.position.x, selectionArrow.transform.position.y);
        }
        if (currentGrenadeName == "Fire")
        {
            selectionArrow.transform.position = new Vector2(firePic.transform.position.x, selectionArrow.transform.position.y);
        }
    }
}
