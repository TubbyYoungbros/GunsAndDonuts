﻿using UnityEngine;
using System.Collections;

public class FragExplosion : MonoBehaviour {

    public int damageMin, damageMax;
    public GameObject body;

    void Start()
    {
        Destroy(body.gameObject, 0.3f);
    }

    void OnTriggerEnter2D(Collider2D obj)
    {
        if (obj.gameObject.tag == "Enemy")
        {
            obj.gameObject.GetComponent<EnemyHealth>().TakeDamage(Random.Range(damageMin, damageMax));
            obj.gameObject.GetComponent<EnemyHealth>().ShowDamageTaken();
        }
    }
}
