﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TemporaryAmmoStand : MonoBehaviour {
    public int baseCost = 5;
    public int newCost;
    public string type;
    public Text price;
    public GameObject tipCanvas;

    public AudioClip suceed;
    public AudioClip error;

    public int baseAmmoCost = 5;

    public PlayerMoneyManager playerManager;
    // Use this for initialization
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter2D(Collider2D obj)
    {
        if (obj.gameObject.tag == "Player")
        {
            PlayerMoneyManager player = obj.gameObject.GetComponent<PlayerMoneyManager>();
            player.enabled = true;
            player.shopType = type;
        }
    }
    void OnTriggerExit2D(Collider2D obj)
    {
        if (obj.gameObject.tag == "Player")
        {
            PlayerMoneyManager player = obj.gameObject.GetComponent<PlayerMoneyManager>();
            player.enabled = false;
            player.shopType = null;
        }
    }
}
