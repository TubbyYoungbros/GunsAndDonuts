﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Shop : MonoBehaviour {

    public int baseCost = 5;
    public int newCost;
    public string type;
    public Text price;
    public GameObject tipCanvas;

    public AudioClip suceed;
    public AudioClip error;

    public int baseAmmoCost = 5;
    public int newAmmoCost = 5;

    public PlayerMoneyManager playerManager;
	// Use this for initialization
	void Start () {
        tipCanvas.SetActive(false);
    }
	
	// Update is called once per frame
	void Update () {

            
        if(this.type == "Ammo")
        {
            price.text = baseAmmoCost.ToString() + "\n" + "Coins";

            baseAmmoCost = newAmmoCost;
        }
    }

    void OnTriggerEnter2D(Collider2D obj)
    {
        if(obj.gameObject.tag == "Player")
        {
            PlayerMoneyManager player = obj.gameObject.GetComponent<PlayerMoneyManager>();
            player.enabled = true;
            player.shopType = type;
            tipCanvas.SetActive(true);
        }
    }
    void OnTriggerExit2D(Collider2D obj)
    {
        if(obj.gameObject.tag == "Player")
        {
            PlayerMoneyManager player = obj.gameObject.GetComponent<PlayerMoneyManager>();
            player.enabled = false;
            player.shopType = null;
            tipCanvas.SetActive(false);
        }
    }
}
