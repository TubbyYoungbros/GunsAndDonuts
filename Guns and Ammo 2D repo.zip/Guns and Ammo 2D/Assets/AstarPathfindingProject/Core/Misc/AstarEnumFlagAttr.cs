using UnityEngine;

namespace Pathfinding {
	/** \author http://wiki.unity3d.com/index.php/EnumFlagPropertyDrawer */
	public class AstarEnumFlagAttribute : PropertyAttribute {
	}
}
