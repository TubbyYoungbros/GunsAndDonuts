﻿using UnityEngine;
using System.Collections;

public class FrozenExplosion : MonoBehaviour {

    public int damageMin, damageMax;
    public GameObject body;

    // Use this for initialization
    void Start () {
        Destroy(body.gameObject, 0.3f);
	}

    void OnTriggerEnter2D(Collider2D obj)
    {
        if (obj.gameObject.tag == "Enemy")
        {
            
            obj.gameObject.GetComponent<EnemyHealth>().TakeDamage(Random.Range(damageMin, damageMax));
            obj.gameObject.GetComponent<FreezingTime>().slowdown = true;
            obj.gameObject.GetComponent<EnemyHealth>().ShowDamageTaken();
        }
    }
}
