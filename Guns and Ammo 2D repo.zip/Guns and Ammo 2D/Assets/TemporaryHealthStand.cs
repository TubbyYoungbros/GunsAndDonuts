﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TemporaryHealthStand : MonoBehaviour {

    public int baseCost = 5;
    public int newCost;
    public string type;
    public Text price;
    public GameObject tipCanvas;
    public GameObject gameManager;

    public AudioClip suceed;
    public AudioClip error;

    public int baseHealthCost = 5;

    public PlayerMoneyManager playerManager;
    // Use this for initialization
    void Start()
    {
        gameManager = GameObject.Find("WaveManager(Clone)");
        baseHealthCost = baseHealthCost * gameManager.GetComponent<WaveSpawner>().waveNumber;
        price.text = baseHealthCost.ToString() + "\n" + "Coins";
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter2D(Collider2D obj)
    {
        if (obj.gameObject.tag == "Player")
        {
            PlayerMoneyManager player = obj.gameObject.GetComponent<PlayerMoneyManager>();
            player.enabled = true;
            player.shopType = type;
            player.baseTempHPCost = baseHealthCost;
        }
    }
    void OnTriggerExit2D(Collider2D obj)
    {
        if (obj.gameObject.tag == "Player")
        {
            PlayerMoneyManager player = obj.gameObject.GetComponent<PlayerMoneyManager>();
            player.enabled = false;
            player.shopType = null;
        }
    }

}
