﻿using UnityEngine;
using System.Collections;

public class PlayerMoneyManager : MonoBehaviour {

    PlayerPickupController moneyManager;
    PlayerCombatManager combatManager;
    PlayerMovementManager playerManager;
    CharacterGrenadeInventory charGrenades;


    public Shop shop;
    public DamageShop damageShop;
    public HealthShop healthShop;
    public SpeedShop speedShop;

    public string shopType;

    public bool buying = false;
    public bool buyingHealth = false;

    public AudioClip suceed;
    public AudioClip error;

    public AudioSource myAudio;

    //Cost
    public int baseAmmoCost = 5;
    public int newAmmoCost = 5;

    public int baseDamageCost = 5;
    public int newDamageCost = 5;

    public int baseHealthCost = 5;
    public int newHealthCost = 5;

    public int baseSpeedCost = 5;
    public int newSpeedCost = 5;

    public int baseTempAmmoCost = 10;
    public int newTempAmmoCost = 5;

    public int baseTempHPCost = 5;

    public int baseFrozenGrenadeCost = 20;
    public int baseGrenadeCost = 10;
    public int baseFireCost = 25;
    public int baseDistraction = 30;

    // Use this for initialization
    void Start () {
        moneyManager = this.gameObject.GetComponent<PlayerPickupController>();
        combatManager = this.gameObject.GetComponent<PlayerCombatManager>();
        playerManager = this.gameObject.GetComponent<PlayerMovementManager>();
        charGrenades = this.gameObject.GetComponent<CharacterGrenadeInventory>();

        shop = GameObject.FindGameObjectWithTag("Shop").GetComponent<Shop>();
        damageShop = GameObject.FindGameObjectWithTag("Damage shop").GetComponent<DamageShop>();
        healthShop = GameObject.FindGameObjectWithTag("Health shop").GetComponent<HealthShop>();
        speedShop = GameObject.FindGameObjectWithTag("Speed shop").GetComponent<SpeedShop>();
        myAudio = GameObject.FindGameObjectWithTag("Audio").GetComponent<AudioSource>();


        shop.newAmmoCost = 5;
        damageShop.newDamageCost = 5;
        healthShop.newHealthCost = 5;
        speedShop.newSpeedCost = 5;
    }
	
	// Update is called once per frame
	void Update () {
        //Debug.Log(controller.coins);
        if(shopType == "Ammo")
        {
            AmmoShop();
        }else if(shopType == "Health")
        {
            HealthShop();
        }else if (shopType == "Damage")
        {
            DamageShop();
        }else if (shopType == "Speed")
        {
            SpeedShop();
        }else if (shopType == "TempAmmo")
        {
            TempAmmoShop();
        }else if (shopType == "TempHp")
        {
            TempHPShop();
        }else if(shopType == "Frozen")
        {
            FrozenGrenade();
        }else if (shopType == "Regular")
        {
            RegularGrenade();
        }
        else if (shopType == "Fire")
        {
            FireGrenade();
        }
        else if (shopType == "Diversion")
        {
            DistractionGrenade();
        }


    }

    void AmmoShop()
    {
        if (Input.GetKeyUp(KeyCode.E))
        {
            if(shop.baseAmmoCost <= moneyManager.coins)
            {
                
                moneyManager.coins -= baseAmmoCost;
                newAmmoCost = baseAmmoCost + 5;
                baseAmmoCost = newAmmoCost;
                shop.newAmmoCost = baseAmmoCost;

                combatManager.maxAmmoInMag += 2;
                combatManager.curAmmoInMag = combatManager.maxAmmoInMag;
                combatManager.totalAmmo += combatManager.ammoToBuy;
                //play an ammo sound
                myAudio.PlayOneShot(suceed);
            }
            else
            {
                //play error sound
                Debug.Log("Cant");
                myAudio.PlayOneShot(error);
            }
        }
    }

    void TempHPShop()
    {
        Debug.Log("Hit 2");
        if (Input.GetKeyUp(KeyCode.E))
        {
            Debug.Log("Hit 3");
            if (moneyManager.coins >= baseTempHPCost)
            {
                Debug.Log("Hit 4");
                if (!buyingHealth)
                {
                    Debug.Log("Hit 5");
                    if (combatManager.curHealth < combatManager.maxHealth)
                    {
                        Debug.Log("Hit 6");
                        moneyManager.coins -= baseTempHPCost;
                        myAudio.PlayOneShot(suceed);
                        combatManager.curHealth = combatManager.maxHealth;
                        combatManager.healthbar.fillAmount = 1;
                        StartCoroutine(BoughtHealth());
                        buyingHealth = true;
                    }
                    else
                    {
                        AudioSource.PlayClipAtPoint(error, Camera.main.transform.position);
                    }
                }else
                {
                    AudioSource.PlayClipAtPoint(error, Camera.main.transform.position);
                }
            }
        }
    }
    void TempAmmoShop()
    {
        if (Input.GetKeyUp(KeyCode.E))
        {
            if (moneyManager.coins >= baseTempAmmoCost)
            {
                if (!buying)
                {
                    if (combatManager.curAmmoInMag < combatManager.maxAmmoInMag)
                    {
                        StartCoroutine(BoughtMag());
                        moneyManager.coins -= baseTempAmmoCost;
                        AudioSource.PlayClipAtPoint(combatManager.reloadSound, Camera.main.transform.position);
                        buying = true;
                    }
                    else
                    {
                        AudioSource.PlayClipAtPoint(error, Camera.main.transform.position);
                    }
                }
                else
                {
                    AudioSource.PlayClipAtPoint(error, Camera.main.transform.position);
                }
            }
            else
            {

            }
        }
    }

    IEnumerator BoughtMag()
    {
        yield return new WaitForSeconds(combatManager.timeBeforeEachShot);
        combatManager.curAmmoInMag = combatManager.maxAmmoInMag;
        combatManager.totalAmmo += combatManager.maxAmmoInMag / 2;
        buying = false;
    }
    IEnumerator BoughtHealth()
    {
        yield return new WaitForSeconds(3);
        buyingHealth = false;
    }
    void DamageShop()
    {
        if (Input.GetKeyUp(KeyCode.E))
        {
            if (damageShop.baseDamageCost <= moneyManager.coins)
            {
               
                moneyManager.coins -= baseDamageCost;
                newDamageCost = baseDamageCost + 5;
                baseDamageCost = newDamageCost;
                damageShop.newDamageCost = baseDamageCost;

                combatManager.damage += 5;
                //play an ammo sound
                myAudio.PlayOneShot(suceed);
            }
            else
            {
                //play error sound
                Debug.Log("Cant");
                myAudio.PlayOneShot(error);
            }
        }
    }

    void HealthShop()
    {
        if (Input.GetKeyUp(KeyCode.E))
        {
            if (healthShop.baseHealthCost <= moneyManager.coins)
            {
                
                moneyManager.coins -= baseHealthCost;
                newHealthCost = baseHealthCost + 5;
                baseHealthCost = newHealthCost;
                healthShop.newHealthCost = baseHealthCost;

                combatManager.maxHealth += 20;
                combatManager.curHealth = combatManager.maxHealth;
                combatManager.healthbar.fillAmount = 1;

                //play an ammo sound
                myAudio.PlayOneShot(suceed);
            }
            else
            {
                //play error sound
                Debug.Log("Cant");
                myAudio.PlayOneShot(error);
            }
        }
    }

    void SpeedShop()
    {
        if (Input.GetKeyUp(KeyCode.E))
        {
            if ( speedShop.baseSpeedCost <= moneyManager.coins)
            {
                
                moneyManager.coins -= baseSpeedCost;
                newSpeedCost = baseSpeedCost + 5;
                baseSpeedCost = newSpeedCost;
                speedShop.newSpeedCost = baseSpeedCost;

                playerManager.moveSpeed += 0.15f;
                //playerManager.diagonalMove += 0.01f;
                combatManager.timeToReload -= 0.1f;
                combatManager.audioM.pitch += 0.065f;
                combatManager.timeBeforeEachShot -= 0.003f;
                combatManager.bulletSpeed += 20;

                //play an ammo sound
                myAudio.PlayOneShot(suceed);
            }
            else
            {
                //play error sound
                Debug.Log("Cant");
                myAudio.PlayOneShot(error);
            }
        }
    }

    void FrozenGrenade()
    {
        if (Input.GetKeyUp(KeyCode.E))
        {
            if(charGrenades.frozenGrenades <= 0)
            {
                if (baseFrozenGrenadeCost <= moneyManager.coins)
                {
                    moneyManager.coins -= baseFrozenGrenadeCost;
                    charGrenades.frozenGrenades = 1;
                    charGrenades.grenadeList.Add("Frozen");
                    //play an ammo sound
                    myAudio.PlayOneShot(suceed);
                }
                else
                {
                    //play error sound
                    Debug.Log("Cant");
                    myAudio.PlayOneShot(error);
                }
            }
            else
            {
                //play error sound
                Debug.Log("Cant");
                myAudio.PlayOneShot(error);
            }
        }
    }

    void DistractionGrenade()
    {
        if (Input.GetKeyUp(KeyCode.E))
        {
            if (charGrenades.leadingGrenades <= 0)
            {
                if (baseDistraction <= moneyManager.coins)
                {
                    moneyManager.coins -= baseDistraction;
                    charGrenades.leadingGrenades = 1;
                    charGrenades.grenadeList.Add("Leading");
                    //play an ammo sound
                    myAudio.PlayOneShot(suceed);
                }
                else
                {
                    //play error sound
                    Debug.Log("Cant");
                    myAudio.PlayOneShot(error);
                }
            }
            else
            {
                //play error sound
                Debug.Log("Cant");
                myAudio.PlayOneShot(error);
            }
        }
    }

    void RegularGrenade()
    {
        if (Input.GetKeyUp(KeyCode.E))
        {
            if (charGrenades.regularGrenades <= 0)
            {
                if (baseGrenadeCost <= moneyManager.coins)
                {
                    moneyManager.coins -= baseGrenadeCost;
                    charGrenades.regularGrenades = 1;
                    charGrenades.grenadeList.Add("Regular");
                    //play an ammo sound
                    myAudio.PlayOneShot(suceed);
                }
                else
                {
                    //play error sound
                    Debug.Log("Cant");
                    myAudio.PlayOneShot(error);
                }
            }
            else
            {
                //play error sound
                Debug.Log("Cant");
                myAudio.PlayOneShot(error);
            }
        }
    }
    void FireGrenade()
    {
        if (Input.GetKeyUp(KeyCode.E))
        {
            if (charGrenades.fireGrenades <= 0)
            {
                if (baseGrenadeCost <= moneyManager.coins)
                {
                    moneyManager.coins -= baseFireCost;
                    charGrenades.fireGrenades = 1;
                    charGrenades.grenadeList.Add("Fire");
                    //play an ammo sound
                    myAudio.PlayOneShot(suceed);
                }
                else
                {
                    //play error sound
                    Debug.Log("Cant");
                    myAudio.PlayOneShot(error);
                }
            }
            else
            {
                //play error sound
                Debug.Log("Cant");
                myAudio.PlayOneShot(error);
            }
        }
    }
}
