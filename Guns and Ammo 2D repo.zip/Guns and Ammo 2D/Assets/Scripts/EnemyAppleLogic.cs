﻿using UnityEngine;
using System.Collections;

public class EnemyAppleLogic : MonoBehaviour {

    public GameObject body;
    public GameObject player;
    public float speed;
    public float maxSpeed;
    public int lookDir;
    Rigidbody2D myRB;

    public Animator bodyAnim;

    // Use this for initialization
    void Start () {
        player = GameObject.FindGameObjectWithTag("Player");
        lookDir = 1;
        myRB = GetComponent<Rigidbody2D>();
	}

    void Update()
    {
        LookTo();
    }
    void FixedUpdate()
    {
        Runto();
    }

    void LookTo()
    {
        Vector3 playPos = player.transform.position;
        if (playPos.x <= transform.position.x)
        {
            lookDir = -1;
        }
        else if (playPos.x >= transform.position.x)
        {
            lookDir = 1;
        }
        body.transform.localScale = new Vector3(lookDir, transform.localScale.y, transform.localScale.z);
    }

    void Runto()
    {
        Vector3 dir = player.transform.position - transform.position;

        dir.Normalize();

        transform.position = transform.position + dir * speed * Time.deltaTime;

    }
}
