﻿using UnityEngine;
using System.Collections;

public class PauseManager : MonoBehaviour {

    public GameObject pauseCanvas;
    public GameObject guiCanvas;
    public GameObject selectionPanel;
    bool isPaused;
    public bool dead = false;

    // Use this for initialization
    void Start () {
	    pauseCanvas.SetActive(false);
        selectionPanel.SetActive(true);
        guiCanvas.SetActive(false);
	}
	
	// Update is called once per frame
	void Update () {
            if (Input.GetKey(KeyCode.Escape))
            {
                if (!isPaused)
                {
                    pauseCanvas.SetActive(true);
                    guiCanvas.SetActive(false);
                    Time.timeScale = 0;
                    isPaused = true;
                }
            }

        if (dead)
        {
            Death();
        }
    }

    public void Death()
    {
        Destroy(pauseCanvas);
        guiCanvas.SetActive(false);
    }

    public void Resume()
    {
        pauseCanvas.SetActive(false);
        guiCanvas.SetActive(true);
        Time.timeScale = 1;
        isPaused = false;
    }

    public void LoadLevel(string level)
    {
        //TODO have a spin animation and "YOU LASTED XXX Roundss
        UnityEngine.SceneManagement.SceneManager.LoadScene(level, UnityEngine.SceneManagement.LoadSceneMode.Single);
        Time.timeScale = 1;
    }
    public void ExitGame()
    {
        Application.Quit();
    }
}
