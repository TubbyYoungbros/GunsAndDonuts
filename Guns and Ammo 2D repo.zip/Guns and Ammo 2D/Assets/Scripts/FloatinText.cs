﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class FloatinText : MonoBehaviour {

    public Animator animator;
    private Text damageText;

    void Start()
    {
        AnimatorClipInfo[] clipInfo = animator.GetCurrentAnimatorClipInfo(0);
        Destroy(gameObject, clipInfo[0].clip.length);
        damageText = animator.GetComponent<Text>();
    }

    public void SetText(float number)
    {
        animator.GetComponent<Text>().text = number.ToString();
    }
}
