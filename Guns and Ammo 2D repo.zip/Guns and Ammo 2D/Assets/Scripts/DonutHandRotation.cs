﻿using UnityEngine;
using System.Collections;

public class DonutHandRotation : MonoBehaviour {
    
    // Update is called once per frame
    void Update()
    {
        //takes the mouseposition - the difference between the object and the WorldToScreenPoint of the mouse
        Vector3 dir = Input.mousePosition - Camera.main.WorldToScreenPoint(transform.position);
        //creates a angle variable and turns x,y coords from DIR to a radian degree
        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
        //rotates the object to the radian using quaternion agle axis
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

        //used to flip the arms instead of rotating around one axis, used to always stay upright
        int lookDir = 1;
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        if (mousePos.x >= transform.position.x)
        {
            lookDir = 1;
        }
        else if (mousePos.x <= transform.position.x)
        {
            lookDir = -1;
        }
        transform.localScale = new Vector3(transform.localScale.x, lookDir, transform.localScale.z);
    }
}
