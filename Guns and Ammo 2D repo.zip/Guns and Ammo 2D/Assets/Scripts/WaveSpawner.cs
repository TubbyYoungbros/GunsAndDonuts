﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class WaveSpawner : MonoBehaviour {
    
    public enum SpawnState { SPAWNING, WAITING, COUNTING, STARTING};

    [System.Serializable]
    public class Wave
    {
        public string name;
        public Transform enemy;
        public Transform enemy2;
        public Transform enemy3;
        public int count;
        public int count2;
        public int count3;
        public float rate;
    }

    private GameObject[] spawnPoints;
    private Text countDownText;
    private Text waveNumberText, endingText;
    private GameObject fullPlatform;

    [SerializeField]
    private GameObject ammoShop, damageShop, healthShop, speedShop, shopWalls;
    [SerializeField]
    private GameObject tempAmmo, tempHealth, hintText, enemiesLeft;

    private GameObject tempTempAmmo;
    private GameObject tempTempHP;

    public AudioClip beep;

    public Wave[] waves;
    private int nextWave = 0;

    public int enemyLeft;

    public float timeBetweenWaves = 90f;
    public float waveCountdown;
    public bool canCount = false;

    private float searchCountdown = 1f;

    public AudioSource myAudio;

    public int waveNumber = 1;
    public float multiplyHealth = 2.7f;
    public float multiplySpeed = .04f;

    private SpawnState state = SpawnState.COUNTING;

    void Start()
    {
        waveCountdown = timeBetweenWaves;
        spawnPoints = GameObject.FindGameObjectsWithTag("Spawner");
        countDownText = Camera.main.transform.GetChild(0).FindChild("Timer").GetComponent<Text>();
        hintText = GameObject.Find("HintTextTime");
        enemiesLeft = GameObject.Find("EnemiesLeft");
        waveNumberText = Camera.main.transform.GetChild(0).FindChild("Round Text").GetComponent<Text>();
        endingText = Camera.main.transform.GetChild(0).FindChild("Ending Level Text").GetComponent<Text>();
        endingText.gameObject.SetActive(false);
        myAudio = GameObject.FindGameObjectWithTag("Audio").GetComponent<AudioSource>();
        fullPlatform = GameObject.Find("StonePlatform");

        ammoShop = GameObject.FindGameObjectWithTag("Shop");
        damageShop = GameObject.FindGameObjectWithTag("Damage shop");
        healthShop = GameObject.FindGameObjectWithTag("Health shop");
        speedShop = GameObject.FindGameObjectWithTag("Speed shop");
        shopWalls = GameObject.FindGameObjectWithTag("Shop Walls");

        countDownText.gameObject.SetActive(false);
        enemiesLeft.SetActive(false);
        shopWalls.SetActive(false);
        hintText.SetActive(true);
    }


    void Update()
    {
        if (waveCountdown == 5)
        {
            StartCoroutine(ClockBeep());
        }

        enemiesLeft.GetComponent<Text>().text = "Enemies Left: " + enemyLeft.ToString();

        waveNumberText.text = "Wave " + waveNumber.ToString();

        if (waveNumber > waves.Length)
        {
            endingText.gameObject.SetActive(true);
        }

        if (state == SpawnState.WAITING)
        {
            if (!EnemyIsAlive())
            {
                WaveCompleted();
            }
            else
            {
                return;
            }
        }

        if (waveCountdown <= 0)
        {
            if (state != SpawnState.SPAWNING)
            {
                //Instantiate(tempAmmo, tempAmmo.transform.position, transform.rotation);
                //tempTempAmmo = tempAmmo;

                //Instantiate(tempHealth, tempHealth.transform.position, transform.rotation);
                //tempTempHP = tempHealth;

                StartCoroutine(SpawnWave(waves[nextWave]));
            }
            canCount = false;
            countDownText.gameObject.SetActive(false);
            enemiesLeft.SetActive(true);
            shopWalls.SetActive(true);
            fullPlatform.SetActive(false);
        }
        else if(canCount)
        {
            waveCountdown -= Time.deltaTime;
            hintText.SetActive(false);
            countDownText.gameObject.SetActive(true);
            countDownText.text = (Mathf.Round(waveCountdown)).ToString();
        }
        
    }

    IEnumerator ClockBeep()
    {
        for(int i = 0; i < 6; i++)
        {
            myAudio.PlayOneShot(beep);
            yield return new WaitForSeconds(.86f);
        }
    }

    void WaveCompleted()
    {
        state = SpawnState.COUNTING;
        waveCountdown = timeBetweenWaves;
        if (nextWave + 1 > waves.Length - 1)
        {
            nextWave = 0;
        }
        else
        {
            nextWave++;
        }
        waveNumber++;
        fullPlatform.SetActive(true);
        shopWalls.SetActive(false);
        hintText.SetActive(true);
        enemiesLeft.SetActive(false);
    }

    bool EnemyIsAlive()
    {
        searchCountdown -= Time.deltaTime;
        if (searchCountdown <= 0f)
        {
            searchCountdown = 1f;
            if (GameObject.FindGameObjectWithTag("Enemy") == null)
            {
                return false;
            }
        }

        return true;
    }

    IEnumerator SpawnWave(Wave _wave)
    {
        state = SpawnState.SPAWNING;

        for(int i = 0; i < _wave.count; i++)
        {
            SpawnEnemy(_wave.enemy);
            yield return new WaitForSeconds(1 / _wave.rate);
        }if(_wave.enemy2 != null)
        {
            for (int i = 0; i < _wave.count2; i++)
            {
                SpawnEnemy(_wave.enemy2);
                yield return new WaitForSeconds(1 / _wave.rate);
            }
        }
        if (_wave.enemy3 != null)
        {
            for (int i = 0; i < _wave.count3; i++)
            {
                SpawnEnemy(_wave.enemy3);
                yield return new WaitForSeconds(1 / _wave.rate);
            }
        }

        state = SpawnState.WAITING;

        yield break;        
    }

    void SpawnEnemy(Transform _enemy)
    {
        float upgradeNumber = waveNumber * multiplyHealth;
        float speedUpgrade = waveNumber * multiplySpeed;
        GameObject _sp = spawnPoints[ Random.Range(0, spawnPoints.Length)];
        Instantiate(_enemy, _sp.transform.position, transform.rotation);
        enemyLeft++;
    }
}
