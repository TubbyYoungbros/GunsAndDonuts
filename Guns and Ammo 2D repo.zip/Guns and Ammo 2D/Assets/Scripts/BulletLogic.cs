﻿using UnityEngine;
using System.Collections;

public class BulletLogic : MonoBehaviour {

    Rigidbody2D myRB;
    public float damageHigh;
    public float damageLow;
    public float totalDamage;
    public string Type;

    // Use this for initialization
    void Start()
    {
        myRB = GetComponent<Rigidbody2D>();

        StartCoroutine(DestroyAfterSeconds());

        float dmgToGive = Random.Range(damageLow, damageHigh);
        dmgToGive = Mathf.Round(dmgToGive * 10f) / 10f;
        totalDamage = dmgToGive;

        //takes the mouseposition - the difference between the object and the WorldToScreenPoint of the mouse
        Vector3 dir = Input.mousePosition - Camera.main.WorldToScreenPoint(transform.position);
        //creates a angle variable and turns x,y coords from DIR to a radian degree
        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
        //rotates the object to the radian using quaternion agle axis
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.tag == "Enemy")
        {
            if (col.gameObject.GetComponent<EnemyHealth>().curHealth >= totalDamage)
            {
                col.gameObject.GetComponent<EnemyHealth>().TakeDamage(totalDamage);
                if(Type != "Glazed")
                {
                    col.gameObject.GetComponent<EnemyHealth>().ShowDamageTaken();
                }else
                {
                    col.gameObject.GetComponent<EnemyHealth>().ShowGlazed();
                }
                Destroy(this.gameObject);
            }else if(col.gameObject.GetComponent<EnemyHealth>().curHealth < totalDamage)
            {
                float damageLeft = totalDamage - col.gameObject.GetComponent<EnemyHealth>().curHealth;
                col.gameObject.GetComponent<EnemyHealth>().TakeDamage(totalDamage);
                totalDamage -= damageLeft;
                
            }
            //Destroy(this.gameObject);
        }else if(col.gameObject.tag == "Wall")
        {
            Destroy(this.gameObject);
        }
    }

    public IEnumerator DestroyAfterSeconds()
    {
        yield return new WaitForSeconds(2f);
        Destroy(this.gameObject);
    }
}
