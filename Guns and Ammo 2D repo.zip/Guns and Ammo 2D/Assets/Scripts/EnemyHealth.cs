﻿using System.Collections;
using UnityEngine;

public class EnemyHealth : MonoBehaviour {

    public string Type;
    public float maxHealth;
    public float curHealth;
    public GameObject[] bodyParts;
    public GameObject[] crumbs;
    public GameObject crumbSpawn;
    GameObject crumbToDrop;
    public int timesToDrop;
    GameObject junk;
    public AudioClip hit;
    public AudioClip death;
    public float volume;

    public int coinDropAmtLow;
    public int coinDropAmt;
    public GameObject coin;

    public int GrapesToDrop = 6;
    public GameObject grapeToDrop;

    public GameObject cherryToDrop;
    public Rigidbody2D cherryPieceToDrop;
    public GameObject circleDeath;
    public int cherryPiecesToDrop;

    public float distFromCharacter;

    public bool onFire = false;
    public float fireDamage;
    public float maxFiretime;
    public float fireTime;
    public bool fired;
    public GameObject playerFire;

    public AudioSource myAudio;
    public WaveSpawner myWave;


    // Use this for initialization
    void Start()
    {
        junk = GameObject.Find("Junk Folder");
        maxFiretime = 4;
        fireDamage = 20;
        playerFire.SetActive(false);
        myAudio = GameObject.FindGameObjectWithTag("Audio").GetComponent<AudioSource>();
        myWave = GameObject.Find("WaveManager(Clone)").GetComponent<WaveSpawner>();

        float multiplyHealth = myWave.waveNumber * myWave.multiplyHealth;
        maxHealth = maxHealth + multiplyHealth;
        curHealth = maxHealth;
    }

    void Update()
    {
        if (onFire)
        {
            fireTime -= Time.deltaTime;
            //enable the fire sprite
            playerFire.SetActive(true);
            if (!fired)
            {
                StartCoroutine(FireTiming());
                fired = true;
            }
            if(fireTime <= 0)
            {
                onFire = false;
                playerFire.SetActive(false);
            }
        }
    }

    private IEnumerator FireTiming()
    {
        yield return new WaitForSeconds(.6f);
        TakeDamage(fireDamage);
        ShowDamageTaken();
        if (onFire)
        {
            StartCoroutine(FireTiming());
        }

    }

    public void TakeDamage(float dmgTaken)
    {

            if (curHealth > 0)
            {

                myAudio.PlayOneShot(hit);
            }
        curHealth -= dmgTaken;
        if (curHealth <= 0)
        {
            DeathCall();
        }
    }

    public void ShowDamageTaken()
    {
        for (int i = 0; i <= timesToDrop; i++)
        {
            
            int crumbNumber = UnityEngine.Random.Range(0, crumbs.Length);
            float randomDropZoneX = UnityEngine.Random.Range(-distFromCharacter, distFromCharacter);
            float randomDropZoneY = UnityEngine.Random.Range(-distFromCharacter, distFromCharacter);
            crumbToDrop = crumbs[crumbNumber];

            GameObject crumb1 = (GameObject)Instantiate(crumbToDrop, crumbSpawn.transform.position + new Vector3(randomDropZoneX, randomDropZoneY, 0), Quaternion.identity);
            crumb1.transform.SetParent(junk.transform);
        }
    }

    public void ShowGlazed()
    {
        int crumbNumber = UnityEngine.Random.Range(0, crumbs.Length);
        float randomDropZoneX = UnityEngine.Random.Range(-distFromCharacter, distFromCharacter);
        float randomDropZoneY = UnityEngine.Random.Range(-distFromCharacter, distFromCharacter);
        crumbToDrop = crumbs[crumbNumber];

        GameObject crumb1 = (GameObject)Instantiate(crumbToDrop, crumbSpawn.transform.position + new Vector3(randomDropZoneX, randomDropZoneY, 0), Quaternion.identity);
        crumb1.transform.SetParent(junk.transform);
    }

    public void DeathCall()
    {
        int coinsToDrop = Random.Range(0, coinDropAmt + 1);
        Debug.Log(coinsToDrop);
        for(int i = 0; i < coinsToDrop; i++)
        {
            float dropPosX = Random.Range((transform.position.x - distFromCharacter), (transform.position.x + distFromCharacter));
            float dropPosY = Random.Range((transform.position.y - distFromCharacter), (transform.position.y + distFromCharacter));
            Vector3 dropPos = new Vector3(dropPosX, dropPosY, 0);

            Instantiate(coin, dropPos, transform.rotation);
        }


        if(Type == "Grapevine")
        {
            for(int i = 0; i < GrapesToDrop; i++)
            {
                float dropPosX = Random.Range((transform.position.x - .2f), (transform.position.x + .2f));
                float dropPosY = Random.Range((transform.position.y - .2f), (transform.position.y + .2f));

                Vector3 dropPos = new Vector3(dropPosX, dropPosY, 0);

                Instantiate(grapeToDrop, dropPos, transform.rotation);
            }
        }


        if (Type == "DoubleCherry")
        {
            Instantiate(cherryToDrop, new Vector2(transform.position.x + .26f, transform.position.y + .046f), transform.rotation);
            Instantiate(cherryToDrop, new Vector2(transform.position.x - .33f, transform.position.y + .046f), transform.rotation);
        }


        if (Type == "Cherry")
        {
            Instantiate(circleDeath, transform.position, transform.rotation);
            for (int i = 0; i < cherryPiecesToDrop; i++)
            {
                float randomDropZoneX = Random.Range(-1.05f, 1.05f);
                float randomDropZoneY = Random.Range(-1.05f, 1.05f);

                Rigidbody2D crumb1 = (Rigidbody2D)Instantiate(cherryPieceToDrop, crumbSpawn.transform.position + new Vector3(randomDropZoneX, randomDropZoneY, 0), Quaternion.identity);

                float movDir = Random.Range(-1f, 1f);
                float movDirTwo = Random.Range(-1f, 1f);
                crumb1.AddForce(new Vector2(movDir, movDirTwo) * 100f);
                crumb1.transform.SetParent(junk.transform);
            }
        }
        curHealth = 0;
        if (Type != "Grape")
        {
            myWave.enemyLeft--;
        }
        myAudio.PlayOneShot(death);
        Destroy(this.gameObject);
        //play death animation; 
    }
}
