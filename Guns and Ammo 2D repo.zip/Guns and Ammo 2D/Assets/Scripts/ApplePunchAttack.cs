﻿using UnityEngine;
using System.Collections;

public class ApplePunchAttack : MonoBehaviour {

    public float damageHigh;
    public float damageLow;
    public bool canSwing;
    public GameObject player;

    // Use this for initialization
    void Start()
    {
        canSwing = true;
        player = GameObject.FindWithTag("Player");
    }

    // Update is called once per frame
    void Update()
    {
        LookTo();
    }

    public void OnTriggerStay2D(Collider2D collidedObj)
    {
        if (canSwing)
        {
            if (collidedObj.tag == "Player")
            {
                Debug.Log("hit enemy");
                float damageToGive = Random.Range(damageLow, damageHigh);
                damageToGive = Mathf.Round(damageToGive * 10f) / 10f;
                collidedObj.gameObject.GetComponent<PlayerCombatManager>().TakeDamage(damageToGive);
                StartCoroutine(WaitTillNextSwing());
                canSwing = false;
            }
        }
    }

    public void LookTo()
    {
        //takes the mouseposition - the difference between the object and the WorldToScreenPoint of the mouse
        Vector3 dir = player.transform.position - transform.position;
        //creates a angle variable and turns x,y coords from DIR to a radian degree
        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
        //rotates the object to the radian using quaternion agle axis
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
    }

    IEnumerator WaitTillNextSwing()
    {
        yield return new WaitForSeconds(.8f);
        canSwing = true;
    }
}
