﻿using UnityEngine;
using System.Collections;

public class LevelManager : MonoBehaviour {

    public Texture2D cursorTexture;
    public GameObject creditScreen;
    public GameObject controlsScreen;

    void Start()
    {
        Cursor.SetCursor(cursorTexture, new Vector2(32,32), CursorMode.Auto);
    }

    public void LoadLevel(string level)
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(level, UnityEngine.SceneManagement.LoadSceneMode.Single);
    }
    public void ExitGame()
    {
        Application.Quit();
    }
    public void Credits()
    {
        creditScreen.SetActive(true);
    }
    public void noCredits()
    {
        creditScreen.SetActive(false);
    }
    public void Control()
    {
        controlsScreen.SetActive(true);
    }
    public void noControl()
    {
        controlsScreen.SetActive(false);
    }
}
