﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerCombatManager : MonoBehaviour {

    public GameObject waveManager;
    public CameraShake gameManager;

    public enum State { RELOADING, NORMAL, PROCESSING };

    private State state = State.NORMAL;

    public string type;

    public float camShakeAmt;
    public GameObject bulletToUse;
    public float bulletSpeed;
    public Transform bulletSpawn;
    public GameObject bulletFolder;
    public float timeBeforeEachShot;
    public float timeToReload;
    public AudioClip gunShot;
    public AudioClip reloadSound;
    public int totalAmmo;
    public int ammoToBuy;
    public int maxAmmoInMag;
    public int curAmmoInMag;
    bool canShoot;
    bool canReload;
    bool isReloading;
    private ScreenShaker mainCam;
    public float shootingShake; 
    public Image healthbar;
    public Text ammoText;
    public Text reloadText;
    public float maxHealth;
    public float curHealth;
    public AudioSource audioM;
    public AudioSource audioShoot;

    public int numberOfBulletsPerShot;
    public float bulletBurst;
    public float minimumShootAngle;
    public float maximumShootAngle;

    public GameObject body, gun, canvas, deathLight, deathSprite, deadPanel;

    public GameObject muzzleFlash;

    private Rigidbody2D myRB;
    
    public float blowBackfromGun;

    public int damage;


    public int TotalAmmo
    {
        get{ return totalAmmo; }
        set{ totalAmmo = value; }
    }

    // Use this for initialization
    void Start()
    {

        Instantiate(waveManager, Vector2.zero, transform.rotation);

        canShoot = true;
        canReload = true;
        isReloading = false;

        audioM = GetComponent<AudioSource>();

        myRB = GetComponent<Rigidbody2D>();
        bulletFolder = GameObject.Find("BulletFolder");
        ammoText = GameObject.Find("Ammo").GetComponent<Text>();
        reloadText = GameObject.Find("ReloadText").GetComponent<Text>();
        reloadText.gameObject.SetActive(false);
        mainCam = Camera.main.GetComponent<ScreenShaker>();
        gameManager = GameObject.Find("GameManager").GetComponent<CameraShake>();
        audioShoot = GameObject.FindGameObjectWithTag("AudioShoot").GetComponent<AudioSource>();
        audioShoot.clip = gunShot;

        deadPanel = GameObject.Find("Dead Canvas");
        deadPanel.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        ProcessInputs();
        ammoText.text = curAmmoInMag + "/" + TotalAmmo;

        if(curAmmoInMag < maxAmmoInMag)
        {
            reloadText.gameObject.SetActive(true);
        }
        else
        {
            reloadText.gameObject.SetActive(false);
        }

    }

    void ProcessInputs()
    {
        if (type != "Glazed")
        {
            if (state != State.RELOADING)
            {
                if (state != State.PROCESSING)
                {
                    if (!isReloading)
                    {
                        if (Input.GetMouseButton(0))
                        {
                            if (Time.timeScale > 0)
                            {
                                if (canShoot)
                                {
                                    if (curAmmoInMag >= 1)
                                    {
                                        canShoot = false;
                                        StartCoroutine(TimeToShoot());
                                        //have an animator trigger here and the reset it
                                    }
                                }
                            }
                        }
                        if (curAmmoInMag == 0 && totalAmmo > 0)
                        {
                            state = State.PROCESSING;
                            StartCoroutine(TimeToReload());
                            isReloading = true;
                            canReload = false;
                            canShoot = false;
                        }
                    }
                }
            }
            if (state == State.NORMAL)
            {
                if (Input.GetKeyUp(KeyCode.R))
                {
                    if (curAmmoInMag < maxAmmoInMag)
                    {
                        state = State.RELOADING;
                        StartCoroutine(ManualReload());
                        isReloading = true;
                        canReload = false;
                        canShoot = false;
                    }
                }
            }


        }else if(type == "Glazed")
        {

            if (state != State.RELOADING)
            {
                if (state != State.PROCESSING)
                {
                    if (!isReloading)
                    {
                        if (Input.GetMouseButton(0))
                        {
                            if (Time.timeScale > 0)
                            {
                                if (canShoot)
                                {
                                    if (curAmmoInMag >= 1)
                                    {
                                        canShoot = false;
                                        
                                        StartCoroutine(TimeToShotgunShoot());
                                        
                                        //have an animator trigger here and the reset it
                                    }
                                }
                            }
                        }
                        if (curAmmoInMag == 0 && totalAmmo > 0)
                        {
                            state = State.PROCESSING;
                            StartCoroutine(TimeToReload());
                            isReloading = true;
                            canReload = false;
                            canShoot = false;
                        }
                    }
                }
            }
            if (state == State.NORMAL)
            {
                if (Input.GetKeyUp(KeyCode.R))
                {
                    if (curAmmoInMag < maxAmmoInMag)
                    {
                        state = State.RELOADING;
                        StartCoroutine(ManualReload());
                        isReloading = true;
                        canReload = false;
                        canShoot = false;
                    }
                }
            }
        }
    }

    public void TakeDamage(float dmgTaken)
    {
        curHealth -= dmgTaken;
        FloatingTextController.CreateFloatingText(dmgTaken, transform);
        if (curHealth <= 0)
        {
            DeathCall();
            healthbar.fillAmount = curHealth / maxHealth;
        }
        healthbar.fillAmount = curHealth / maxHealth;
    }

    public void DeathCall()
    {
        if (curHealth <= 0)
        {
            //have an animation
            canShoot = false;
            canReload = false;
            isReloading = false;
            this.gameObject.GetComponent<BoxCollider2D>().enabled = false;
            Destroy(this.gameObject.GetComponent<Rigidbody2D>());
            body.SetActive(false);
            gun.SetActive(false);
            canvas.SetActive(false);
            deathLight.SetActive(true);
            PlayerMovementManager playerMove = GetComponent<PlayerMovementManager>();
            Destroy(deathSprite, 2.8f);
            playerMove.enabled = false;
            PauseManager pauseManager = GameObject.Find("Level Manager").GetComponent<PauseManager>();
            pauseManager.dead = true;
            StartCoroutine(Death());
            //Time.timeScale = 0;
            //gameObject.SetActive(false);
        }
    }

    public IEnumerator Death()
    {
        yield return new WaitForSeconds(3.4f);
        deadPanel.SetActive(true);
    }


    public IEnumerator TimeToReload()
    {
        if (state != State.RELOADING)
        {
            //AudioSource.PlayClipAtPoint(reloadSound, Camera.main.transform.position);
            
            //audioM.pitch += .1f;
            audioM.Play();
        }
        yield return new WaitForSeconds(timeToReload);

        if(TotalAmmo >= maxAmmoInMag)
        {
            curAmmoInMag = maxAmmoInMag;
            TotalAmmo -= maxAmmoInMag;
        }else if(TotalAmmo > 0 && TotalAmmo < maxAmmoInMag){
            curAmmoInMag = TotalAmmo;
            TotalAmmo = 0;
        }
        canReload = true;
        canShoot = true;
        isReloading = false;
        state = State.NORMAL;
        mainCam.screenShakeAmount = 0;
    }

    public IEnumerator TimeToShoot()
    {
        GameObject bullet = Instantiate(bulletToUse, bulletSpawn.position, transform.rotation) as GameObject;
        Rigidbody2D bulletRB = bullet.GetComponent<Rigidbody2D>();
        BulletLogic bulletLogic = bullet.GetComponent<BulletLogic>();
        bulletLogic.damageHigh += damage;
        bulletLogic.damageLow += damage;

        Vector3 dir = Input.mousePosition - Camera.main.WorldToScreenPoint(transform.position);
        dir = new Vector3(dir.x * 1000, dir.y * 1000, dir.z);
        dir.Normalize();
        bulletRB.AddForce(dir * bulletSpeed);
        bullet.transform.parent = bulletFolder.transform;

       
        audioShoot.PlayOneShot(gunShot);
        
        curAmmoInMag--;

        mainCam.screenShakeAmount = camShakeAmt;
        StartCoroutine(ShotBack());

        //mainCam.ScreenShake(shootingShake);
        muzzleFlash.SetActive(true);
        yield return new WaitForSeconds(.001f);
        muzzleFlash.SetActive(false);
        yield return new WaitForSeconds(timeBeforeEachShot);
        canShoot = true;
    }

    public IEnumerator TimeToShotgunShoot()
    {
        
        audioShoot.Play();
        for (int i = 0; i < numberOfBulletsPerShot; i++)
        {
            yield return new WaitForSeconds(bulletBurst);

            if (curAmmoInMag > 0)
            {
                GameObject bullet = Instantiate(bulletToUse, bulletSpawn.position, Quaternion.Euler(0, 0, transform.eulerAngles.z + Random.Range(minimumShootAngle, maximumShootAngle))) as GameObject;

                Rigidbody2D bulletRB = bullet.GetComponent<Rigidbody2D>();
                BulletLogic bulletLogic = bullet.GetComponent<BulletLogic>();
                bulletLogic.damageHigh += damage;
                bulletLogic.damageLow += damage;

                

                Vector3 dir = Input.mousePosition - Camera.main.WorldToScreenPoint(transform.position);
                dir = new Vector3(dir.x * 1000, dir.y * 1000, dir.z);
                dir.Normalize();

                Vector3 velocity = bulletRB.transform.rotation * dir; //EVEN THOUGH THIS IS RIGHT, I CANNOT FIND ANY DIRECTION TO SPEE THE BULLET UP IN FORCE -- THIS IS MORE OF DIRECTION THAN VELOCITY
                bulletRB.AddForce(velocity * bulletSpeed);
                bullet.transform.parent = bulletFolder.transform;
                StartCoroutine(ShotBack());
            }
        }
        StartCoroutine(ShotBack());
        mainCam.screenShakeAmount = camShakeAmt;
        StartCoroutine(ShotBack());
        muzzleFlash.SetActive(true);
        yield return new WaitForSeconds(.05f);
        muzzleFlash.SetActive(false);
        yield return new WaitForSeconds(timeBeforeEachShot);
        canShoot = true;
        curAmmoInMag--;
    }

    public IEnumerator ShotBack()
    {
        yield return new WaitForSeconds(0.007f);
        Vector3 dir = Input.mousePosition - Camera.main.WorldToScreenPoint(transform.position);
        dir.Normalize();
        myRB.AddForce(-dir * blowBackfromGun);
    }

    public IEnumerator ManualReload()
    {
        //AudioSource.PlayClipAtPoint(reloadSound, Camera.main.transform.position);
        //audioM.pitch += .1f;
        audioM.Play();
        yield return new WaitForSeconds(timeToReload);

        if(curAmmoInMag < maxAmmoInMag)
        {
            int ammoNeeded = maxAmmoInMag - curAmmoInMag;
            if(totalAmmo >= ammoNeeded)
            {
                totalAmmo -= ammoNeeded;
                curAmmoInMag = maxAmmoInMag;
            }if(totalAmmo > 0)
            {
                if(totalAmmo < ammoNeeded)
                {
                    int ammoToAddMinimal = ammoNeeded - totalAmmo;
                    curAmmoInMag += totalAmmo;
                    totalAmmo = 0;
                }
            }
        }

        state = State.NORMAL;
        canReload = true;
        canShoot = true;
        isReloading = false;
        mainCam.screenShakeAmount = 0;
    }
}
