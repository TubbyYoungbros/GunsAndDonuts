﻿using UnityEngine;
using System.Collections;

public class DeletionScript : MonoBehaviour {

    public float timeToDelete;

	// Use this for initialization
	void Start () {
        StartCoroutine(Deletion());
	}

    IEnumerator Deletion()
    {
        yield return new WaitForSeconds(timeToDelete);
        Destroy(this.gameObject);
    }

}
