﻿using UnityEngine;
using System.Collections;
using System;

public class PlayerMovementManager : MonoBehaviour {
    //Movement varibales;
    public float moveSpeed;
    bool playerMoving;
    public AudioClip footstep;
    public float timeBeforeEachStep;
    bool canStep;
    bool canDrop;
    private float curMoveSpeed;
    public float diagonalMove;
    Rigidbody2D myRB;
    public GameObject body;
    public Animator donutAnim;
    public GameObject[] crumbs;
    public Transform crumbDropPoint;
    GameObject crumbToDrop;
    GameObject junk;
    public AudioSource myAudio;

    // Use this for initialization
    void Start()
    {
        myRB = GetComponent<Rigidbody2D>();
        junk = GameObject.Find("Junk Folder");
        myAudio = GameObject.FindGameObjectWithTag("AudioWalk").GetComponent<AudioSource>();
        FloatingTextController.Initialise();
        canDrop = true;
        canStep = true;
    }

    // Update is called once per frame
    void Update()
    {
        LookTo();
    }
    void FixedUpdate()
    {
        Movement();
    }

    void LookTo()
    {
        int lookDir = 1;
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        if (mousePos.x <= transform.position.x)
        {
            lookDir = -1;
        }
        else if (mousePos.x >= transform.position.x)
        {
            lookDir = 1;
        }
        body.transform.localScale = new Vector3(lookDir, transform.localScale.y, transform.localScale.z);
    }


    void Movement()
    {
        if (Input.GetAxisRaw("Horizontal") > 0.5f || Input.GetAxisRaw("Horizontal") < -0.5f)
        {
            myRB.velocity = new Vector2(Input.GetAxisRaw("Horizontal") * curMoveSpeed, myRB.velocity.y);
            playerMoving = true;
        }
        if (Input.GetAxisRaw("Vertical") > 0.5f || Input.GetAxisRaw("Vertical") < -0.5f)
        {
            myRB.velocity = new Vector2(myRB.velocity.x, Input.GetAxisRaw("Vertical") * curMoveSpeed);
            playerMoving = true;
        }

        //stops the character if theres no input
        if (Input.GetAxisRaw("Horizontal") < 0.5f && Input.GetAxisRaw("Horizontal") > -0.5f)
        {
            myRB.velocity = new Vector2(0f, myRB.velocity.y);

        }
        if (Input.GetAxisRaw("Vertical") < 0.5f && Input.GetAxisRaw("Vertical") > -0.5f)
        {
            myRB.velocity = new Vector2(myRB.velocity.x, 0f);

        }
        if (myRB.velocity == Vector2.zero)
        {
            playerMoving = false;
        }

        //stop fast diagonal movement by dividing speed in half then replacing it 
        if (Math.Abs(Input.GetAxisRaw("Horizontal")) > 0.5f && Math.Abs(Input.GetAxisRaw("Vertical")) > 0.5f)
        {
            curMoveSpeed = moveSpeed * diagonalMove;
        }
        else
        {
            curMoveSpeed = moveSpeed;
        }

        if (playerMoving)
        {
            if (canDrop)
            {
                int crumbNumber = UnityEngine.Random.Range(0, crumbs.Length);
                crumbToDrop = crumbs[crumbNumber];
                GameObject crumbDropped = (GameObject)Instantiate(crumbToDrop, crumbDropPoint.position, Quaternion.identity);

                crumbDropped.transform.SetParent(junk.transform);

                StartCoroutine(DropCrumbs());
                canDrop = false;
            }

            if (canStep)
            {
                myAudio.clip = footstep;
                myAudio.Play();
                canStep = false;
                StartCoroutine(FootSteps());
            }
            donutAnim.SetBool("isMoving", true);
        }
        else
        {
            donutAnim.SetBool("isMoving", false);
        }
    }

    public IEnumerator DropCrumbs()
    {
        yield return new WaitForSeconds(.8f);
        canDrop = true;
        crumbToDrop = null;
    }
    public IEnumerator FootSteps()
    {
        yield return new WaitForSeconds(timeBeforeEachStep);
        canStep = true;
    }

}
