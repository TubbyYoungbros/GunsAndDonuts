﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class PlayerPickupController : MonoBehaviour {

    public int coins;
    private Text coinText;
    private PlayerCombatManager combatManager;
    private PlayerMoneyManager playerMoney;
    public AudioClip coinPickup;
    public AudioSource myAudio;
    private float searchCountdown = 4;

	// Use this for initialization
	void Start () {
        coins = 5;
        combatManager = this.GetComponent<PlayerCombatManager>();
        coinText = Camera.main.transform.GetChild(0).FindChild("Coin Text").GetComponent<Text>();
        playerMoney = this.GetComponent<PlayerMoneyManager>();
        StartCoroutine(MilisTillToggle());
        myAudio = GameObject.FindGameObjectWithTag("AudioCoin").GetComponent<AudioSource>();
    }
    void Update()
    {
        coinText.text = coins.ToString() + " Coins";
        if (Input.GetKeyUp(KeyCode.Q))
        {
            coins += 1000;
        }
    }

    IEnumerator MilisTillToggle()
    {
        yield return new WaitForSeconds(.1f);
        playerMoney.enabled = false;
    }
	
	void OnTriggerEnter2D(Collider2D obj)
    {
        if(obj.gameObject.tag == "Coin")
        {
            coins++;
            Destroy(obj.gameObject);
            myAudio.clip = coinPickup;
            myAudio.Play();
            //TODO play sound
        }
        if (obj.gameObject.tag == "Silver Coin")
        {
            coins += 5;
            Destroy(obj.gameObject);
            myAudio.clip = coinPickup;
            myAudio.Play();
            //TODO play sound
        }
        if (obj.gameObject.tag == "Diamond Coin")
        {
            coins += 25;
            Destroy(obj.gameObject);
            myAudio.clip = coinPickup;
            myAudio.Play();
            //TODO play sound
        }
    }
}
