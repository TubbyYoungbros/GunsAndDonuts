﻿using UnityEngine;
using System.Collections;

public class FloatingTextController : MonoBehaviour {

    private static FloatinText popupTextPrefab;
    private static GameObject canvas;

    public static void Initialise()
    {
        canvas = GameObject.Find("Hitting Canvas");
        if (!popupTextPrefab)
        {
            popupTextPrefab = Resources.Load<FloatinText>("Prefabs/PopupTextParent");
        }
    }

    public static void CreateFloatingText(float hitNumber, Transform location)
    {
        FloatinText instance = Instantiate(popupTextPrefab);
        Vector2 screenPosition = Camera.main.WorldToScreenPoint(location.position);
        instance.transform.SetParent(canvas.transform, false);
        instance.transform.position = screenPosition;
        instance.SetText(hitNumber);
    }

}
