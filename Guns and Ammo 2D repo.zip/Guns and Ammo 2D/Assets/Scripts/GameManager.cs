﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {

    public GameObject Strawberry;
    public GameObject Chocolate;
    public GameObject Glazed;
    public GameObject playerToInstantiate;
    public GameObject SelectionCanvas;
    public GameObject guiCanvas;

    public float posX, posY;

    //waves

    

	// Use this for initialization
	void Start () {
        Time.timeScale = 1;
        SelectionCanvas = GameObject.Find("Selection Canvas");
        
	}
	
	// Update is called once per frame
	void Update () {

        
	}

    public void CharactertoSelect(string character)
    {
        if(character == "Strawberry")
        {
            playerToInstantiate = Strawberry;
            ClickedSelect();
        }else if(character == "Chocolate")
        {
            playerToInstantiate = Chocolate;
            ClickedSelect();
        }
        else if (character == "Glazed")
        {
            playerToInstantiate = Glazed;
            ClickedSelect();
        }
    }

    void ClickedSelect()
    {
        Time.timeScale = 1;
        GameObject characterPlayer = (GameObject)Instantiate(playerToInstantiate, new Vector3(posX, posY, 0f), Quaternion.identity);
        SelectionCanvas.SetActive(false);
        guiCanvas.SetActive(true);
    }

   
}
