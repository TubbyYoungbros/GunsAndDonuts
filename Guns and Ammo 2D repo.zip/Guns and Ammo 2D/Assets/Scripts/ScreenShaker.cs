﻿using UnityEngine;
using System.Collections;

public class ScreenShaker : MonoBehaviour {

    private Vector3 screenShakeActive;
    public float screenShakeAmount;
    public float screenShakeDecay;

    // Update is called once per frame
    void Update()
    {
        ScreenStuff();
    }

    void ScreenStuff()
    {
        if (screenShakeAmount > 0)
        {
            screenShakeActive = new Vector3(0,0, UnityEngine.Random.Range(-screenShakeAmount, screenShakeAmount));

            screenShakeAmount -= Time.deltaTime * screenShakeDecay;
        }
        else
        {
            screenShakeActive = Vector3.zero;
            transform.eulerAngles = new Vector3(0f, 0f, 0f);
        }

        transform.eulerAngles += screenShakeActive;
    }

    public void ScreenShake(float toShake)
    {
        screenShakeAmount = toShake;
    }
}
