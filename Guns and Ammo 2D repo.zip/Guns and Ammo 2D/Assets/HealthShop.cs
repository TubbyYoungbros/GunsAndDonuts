﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class HealthShop : MonoBehaviour {

    public int baseCost = 5;
    public int newCost;
    public string type;
    public Text price;
    public GameObject tipCanvas;

    public AudioClip suceed;
    public AudioClip error;

    public int baseHealthCost = 5;
    public int newHealthCost = 5;

    public PlayerMoneyManager playerManager;
    // Use this for initialization
    void Start()
    {
        tipCanvas.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {

        if (this.type == "Health")
        {
            price.text = newHealthCost.ToString() + "\n" + "Coins";
            baseHealthCost = newHealthCost;
        }
    }

    void OnTriggerEnter2D(Collider2D obj)
    {
        if (obj.gameObject.tag == "Player")
        {
            PlayerMoneyManager player = obj.gameObject.GetComponent<PlayerMoneyManager>();
            player.enabled = true;
            player.shopType = type;
            tipCanvas.SetActive(true);
        }
    }
    void OnTriggerExit2D(Collider2D obj)
    {
        if (obj.gameObject.tag == "Player")
        {
            PlayerMoneyManager player = obj.gameObject.GetComponent<PlayerMoneyManager>();
            player.enabled = false;
            player.shopType = null;
            tipCanvas.SetActive(false);
        }
    }
}
