﻿using UnityEngine;
using System.Collections;

public class StopExplosion : MonoBehaviour {

    public Rigidbody2D myBody;

    // Use this for initialization
    void Start()
    {
        myBody = GetComponent<Rigidbody2D>();
        StartCoroutine(StopTime());
    }

    IEnumerator StopTime()
    {
        yield return new WaitForSeconds(.4f);
        myBody.velocity = Vector2.zero;
        myBody.angularVelocity = 0f;
    }
}
