﻿using UnityEngine;
using System.Collections;

public class CherryExplosionAttack : MonoBehaviour {

    public float damageHigh;
    public float damageLow;

    public GameObject parentCherryBomb;
    public AudioClip blowUpSound;

    public Rigidbody2D crumbToDrop;
    public GameObject crumbSpawn;
    public int timesToDropCrumb;

    public GameObject junk;

    // Use this for initialization
    void Start () {
        junk = GameObject.Find("Junk Folder");
    }
	
	// Update is called once per frame
	void Update () {
	
	}

    public void OnTriggerStay2D(Collider2D collidedObj)
    {
  
        if (collidedObj.tag == "Player")
        {
            float damageToGive = Random.Range(damageLow, damageHigh);
            damageToGive = Mathf.Round(damageToGive * 10f) / 10f;
            collidedObj.gameObject.GetComponent<PlayerCombatManager>().TakeDamage(damageToGive);
            AudioSource.PlayClipAtPoint(blowUpSound, Camera.main.transform.position);

            for(int i = 0; i < timesToDropCrumb; i++)
            {
                
                float randomDropZoneX = Random.Range(-1.05f, 1.05f);
                float randomDropZoneY = Random.Range(-1.05f, 1.05f);

                Rigidbody2D crumb1 = (Rigidbody2D)Instantiate(crumbToDrop, crumbSpawn.transform.position + new Vector3(randomDropZoneX, randomDropZoneY, 0), Quaternion.identity);

                float movDir = Random.Range(-1f, 1f);
                float movDirTwo = Random.Range(-1f, 1f);
                crumb1.AddForce(new Vector2(movDir, movDirTwo) * 100f);

                crumb1.transform.SetParent(junk.transform);
            }
            Destroy(parentCherryBomb.gameObject);
        }
    }
}
