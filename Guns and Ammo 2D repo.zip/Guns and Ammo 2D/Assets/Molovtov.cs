﻿using UnityEngine;
using System.Collections;

public class Molovtov : MonoBehaviour {

    public string type;
    public GameObject ExplosionCircle;
    public bool alreadyHit = false;
    public Rigidbody2D[] explosionParticle;
    public int amountOfExplosionParts;

    public AudioClip explosionSound;

    private GameObject junk;

    public GameObject crumbSpawn;

    public float screenShakeAmt;

    public ScreenShaker mainCam;

    public GameObject distractionBomb;

    public GameObject fire;
    public int amountofFire;
    public AudioSource myAudio;

    void Start()
    {
        junk = GameObject.Find("Junk Folder");
        mainCam = Camera.main.GetComponent<ScreenShaker>();
        myAudio = GameObject.FindGameObjectWithTag("Audio").GetComponent<AudioSource>();
    }

    void Update()
    {
        transform.Rotate(0, 0, 5);
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        if (alreadyHit == false)
        {
            if (col.gameObject.tag != "Player")
            {
                alreadyHit = true;
                ExplosionCircle.SetActive(true);
                myAudio.PlayOneShot(explosionSound);
                mainCam.screenShakeAmount = screenShakeAmt;
                for (int i = 0; i < amountOfExplosionParts; i++)
                {

                    float randomDropZoneX = Random.Range(-1.9f, 1.9f);
                    float randomDropZoneY = Random.Range(-1.9f, 1.9f);

                    Rigidbody2D crumb1 = (Rigidbody2D)Instantiate(explosionParticle[0], crumbSpawn.transform.position + new Vector3(randomDropZoneX, randomDropZoneY, 0), Quaternion.identity);

                    float movDir = Random.Range(-1f, 1f);
                    float movDirTwo = Random.Range(-1f, 1f);
                    crumb1.AddForce(new Vector2(movDir, movDirTwo) * Random.Range(100f, 200f));

                    crumb1.transform.SetParent(junk.transform);
                }
                for (int i = 0; i < amountOfExplosionParts; i++)
                {

                    float randomDropZoneX = Random.Range(-1.9f, 1.9f);
                    float randomDropZoneY = Random.Range(-1.9f, 1.9f);

                    Rigidbody2D crumb1 = (Rigidbody2D)Instantiate(explosionParticle[1], crumbSpawn.transform.position + new Vector3(randomDropZoneX, randomDropZoneY, 0), Quaternion.identity);

                    float movDir = Random.Range(-1f, 1f);
                    float movDirTwo = Random.Range(-1f, 1f);
                    crumb1.AddForce(new Vector2(movDir, movDirTwo) * Random.Range(100f, 200f));

                    crumb1.transform.SetParent(junk.transform);
                }

                //fire
                if (type == "Fire")
                {
                    for (int i = 0; i < amountofFire; i++)
                    {
                        float randomDropZoneX = Random.Range(-1.5f, 1.5f);
                        float randomDropZoneY = Random.Range(-1.5f, 1.5f);

                        GameObject fireObject = (GameObject)Instantiate(fire, crumbSpawn.transform.position + new Vector3(randomDropZoneX, randomDropZoneY, 0), Quaternion.identity);
                    }
                }if(type == "Distraction")
                {
                    Instantiate(distractionBomb, transform.position, Quaternion.identity);
                }
            }
        }
    }
}
