﻿using UnityEngine;
using System.Collections;

public class CherryBombDeath : MonoBehaviour {

    public int DamageToDo;

	// Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnTriggerEnter2D(Collider2D obj)
    {
        if(obj.gameObject.tag == "Enemy")
        {
            Debug.Log("Cherry Found Another OBJ Hit Them");
            obj.gameObject.GetComponent<EnemyHealth>().TakeDamage(DamageToDo);
            obj.gameObject.GetComponent<EnemyHealth>().ShowDamageTaken();
            Destroy(gameObject);
        }
    }

}
