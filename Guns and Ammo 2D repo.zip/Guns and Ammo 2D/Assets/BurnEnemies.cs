﻿using UnityEngine;
using System.Collections;

public class BurnEnemies : MonoBehaviour {

	// Use this for initialization
	void Start () {
        Destroy(this.gameObject, Random.Range(6,8));
	}

    void OnTriggerEnter2D(Collider2D obj)
    {
        if(obj.gameObject.tag == "Enemy")
        {
            obj.gameObject.GetComponent<EnemyHealth>().onFire = true;
            obj.gameObject.GetComponent<EnemyHealth>().fireTime = obj.gameObject.GetComponent<EnemyHealth>().maxFiretime;
            obj.gameObject.GetComponent<EnemyHealth>().fired = false;
        }
    }
}
